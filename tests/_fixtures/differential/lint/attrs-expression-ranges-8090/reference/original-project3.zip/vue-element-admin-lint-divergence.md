## vue-element-admin lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 6858a9ad67483025f6a9432a926beb9327037be3
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 131
Baseline messages dropped as foreign-rule directives: 0

Patina findings: 423
Baseline findings: 6798
Comparable baseline findings: 170
Shared: 71
Message differences: 71
Documented divergences: 0
Rule location divergences: 0
False positives: 89 (0.55625)
False negatives: 99 (0.5823529411764706)
Unimplemented upstream findings: 6628
Intentional divergences: 0
Patina-only rule findings: 263
Baseline parse errors: 0
Baseline invalid ranges: 2
Budget verdict: unusable
Budget passed: false

### False positives: 89

| Rule | Findings |
| --- | ---: |
| `vue/no-deprecated-slot-scope-attribute` | 69 |
| `vue/no-deprecated-v-bind-sync` | 14 |
| `vue/no-deprecated-functional-template` | 3 |
| `script/no-duplicate-attr-inheritance` | 1 |
| `script/no-required-prop-with-default` | 1 |
| `vue/require-toggle-inside-transition` | 1 |

### False negatives: 99

| Rule | Findings |
| --- | ---: |
| `vue/no-deprecated-slot-scope-attribute` | 69 |
| `vue/no-deprecated-v-bind-sync` | 14 |
| `vue/no-mutating-props` | 9 |
| `vue/no-deprecated-functional-template` | 3 |
| `vue/no-duplicate-attr-inheritance` | 3 |
| `vue/no-required-prop-with-default` | 1 |

### Rule location divergences: none

### Unimplemented upstream rules: 6628

| Rule | Findings |
| --- | ---: |
| `vue/max-attributes-per-line` | 996 |
| `vue/sort-keys` | 630 |
| `vue/padding-lines-in-component-definition` | 623 |
| `vue/restricted-component-names` | 577 |
| `vue/new-line-between-multi-line-property` | 552 |
| `vue/padding-line-between-tags` | 549 |
| `vue/no-undef-components` | 479 |
| `vue/comment-directive` | 453 |
| `vue/max-len` | 358 |
| `vue/component-api-style` | 287 |
| `vue/script-indent` | 136 |
| `vue/require-prop-comment` | 129 |
| `vue/require-expose` | 121 |
| `vue/no-undef-directives` | 81 |
| `vue/space-infix-ops` | 70 |
| `vue/quote-props` | 66 |
| `vue/singleline-html-element-content-newline` | 50 |
| `vue/key-spacing` | 47 |
| `vue/block-lang` | 43 |
| `vue/require-name-property` | 43 |
| `vue/comma-spacing` | 38 |
| `vue/static-class-names-order` | 31 |
| `vue/object-shorthand` | 27 |
| `vue/object-property-newline` | 23 |
| `vue/no-literals-in-template` | 22 |
| `vue/multiline-html-element-content-newline` | 18 |
| `vue/multiline-ternary` | 18 |
| `vue/prefer-template` | 18 |
| `vue/array-element-newline` | 16 |
| `vue/next-tick-style` | 15 |
| `vue/no-undef-properties` | 15 |
| `vue/enforce-style-attribute` | 14 |
| `vue/object-curly-spacing` | 11 |
| `vue/eqeqeq` | 10 |
| `vue/v-for-delimiter-style` | 7 |
| `vue/v-if-else-key` | 6 |
| `vue/match-component-import-name` | 5 |
| `vue/no-implicit-coercion` | 5 |
| `vue/prefer-single-event-payload` | 5 |
| `vue/html-comment-content-spacing` | 4 |
| `vue/no-constant-condition` | 4 |
| `vue/padding-line-between-blocks` | 4 |
| `vue/block-tag-newline` | 3 |
| `vue/space-in-parens` | 3 |
| `vue/space-unary-ops` | 3 |
| `vue/html-closing-bracket-spacing` | 2 |
| `vue/html-comment-content-newline` | 2 |
| `vue/no-extra-parens` | 2 |
| `vue/no-negated-condition` | 2 |
| `vue/array-bracket-spacing` | 1 |
| `vue/comma-dangle` | 1 |
| `vue/html-comment-indent` | 1 |
| `vue/no-deprecated-delete-set` | 1 |
| `vue/no-empty-pattern` | 1 |

