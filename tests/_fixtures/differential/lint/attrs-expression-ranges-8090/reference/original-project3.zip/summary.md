# Vize Fixture Tool Matrix Report

Projects: 7
Tools: compiler, typechecker, linter, formatter
Runs: 28
Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Runtime: rust-script rustc 1.99.0 (b940084d7 2026-09-28)
Machine: linux/x64, 32 logical CPUs, 121768112128 bytes memory

| Project | Tool | Status | Exit | Files | Requested | Transitive Authored | Transitive Dependencies | Duration (ms) | Output |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| ant-design-vue | compiler | ok | 0 | 731 | - | - | - | 384 | `real-project-results/shard-3/ant-design-vue-compiler.json` |
| ant-design-vue | typechecker | findings | 1 | 1948 | 731 | 1217 | 0 | 10065 | `real-project-results/shard-3/ant-design-vue-typechecker.json` |
| ant-design-vue | linter | findings | 1 | 731 | - | - | - | 155 | `real-project-results/shard-3/ant-design-vue-linter.json` |
| ant-design-vue | formatter | findings | 1 | 731 | - | - | - | 85 | `real-project-results/shard-3/ant-design-vue-formatter.json` |
| vue-element-admin | compiler | ok | 0 | 131 | - | - | - | 52 | `real-project-results/shard-3/vue-element-admin-compiler.json` |
| vue-element-admin | typechecker | findings | 1 | 169 | 131 | 38 | 0 | 1468 | `real-project-results/shard-3/vue-element-admin-typechecker.json` |
| vue-element-admin | linter | findings | 1 | 131 | - | - | - | 68 | `real-project-results/shard-3/vue-element-admin-linter.json` |
| vue-element-admin | formatter | findings | 1 | 131 | - | - | - | 48 | `real-project-results/shard-3/vue-element-admin-formatter.json` |
| bootstrap-vue | compiler | ok | 0 | 22 | - | - | - | 40 | `real-project-results/shard-3/bootstrap-vue-compiler.json` |
| bootstrap-vue | typechecker | ok | 0 | 22 | 22 | 0 | 0 | 958 | `real-project-results/shard-3/bootstrap-vue-typechecker.json` |
| bootstrap-vue | linter | findings | 1 | 22 | - | - | - | 41 | `real-project-results/shard-3/bootstrap-vue-linter.json` |
| bootstrap-vue | formatter | findings | 1 | 22 | - | - | - | 33 | `real-project-results/shard-3/bootstrap-vue-formatter.json` |
| gui-for-singbox | compiler | ok | 0 | 98 | - | - | - | 74 | `real-project-results/shard-3/gui-for-singbox-compiler.json` |
| gui-for-singbox | typechecker | findings | 1 | 99 | 98 | 1 | 0 | 2252 | `real-project-results/shard-3/gui-for-singbox-typechecker.json` |
| gui-for-singbox | linter | ok | 0 | 98 | - | - | - | 63 | `real-project-results/shard-3/gui-for-singbox-linter.json` |
| gui-for-singbox | formatter | findings | 1 | 98 | - | - | - | 50 | `real-project-results/shard-3/gui-for-singbox-formatter.json` |
| vue-draggable-next | compiler | ok | 0 | 30 | - | - | - | 27 | `real-project-results/shard-3/vue-draggable-next-compiler.json` |
| vue-draggable-next | typechecker | ok | 0 | 30 | 30 | 0 | 0 | 701 | `real-project-results/shard-3/vue-draggable-next-typechecker.json` |
| vue-draggable-next | linter | findings | 1 | 30 | - | - | - | 33 | `real-project-results/shard-3/vue-draggable-next-linter.json` |
| vue-draggable-next | formatter | findings | 1 | 30 | - | - | - | 24 | `real-project-results/shard-3/vue-draggable-next-formatter.json` |
| vue-uploader | compiler | ok | 0 | 8 | - | - | - | 20 | `real-project-results/shard-3/vue-uploader-compiler.json` |
| vue-uploader | typechecker | ok | 0 | 8 | 8 | 0 | 0 | 572 | `real-project-results/shard-3/vue-uploader-typechecker.json` |
| vue-uploader | linter | ok | 0 | 8 | - | - | - | 25 | `real-project-results/shard-3/vue-uploader-linter.json` |
| vue-uploader | formatter | findings | 1 | 8 | - | - | - | 25 | `real-project-results/shard-3/vue-uploader-formatter.json` |
| mobile-web-best-practice | compiler | ok | 0 | 7 | - | - | - | 25 | `real-project-results/shard-3/mobile-web-best-practice-compiler.json` |
| mobile-web-best-practice | typechecker | findings | 1 | 24 | 7 | 17 | 0 | 365 | `real-project-results/shard-3/mobile-web-best-practice-typechecker.json` |
| mobile-web-best-practice | linter | findings | 1 | 7 | - | - | - | 20 | `real-project-results/shard-3/mobile-web-best-practice-linter.json` |
| mobile-web-best-practice | formatter | findings | 1 | 7 | - | - | - | 15 | `real-project-results/shard-3/mobile-web-best-practice-formatter.json` |
