## Syntax highlighter semantic divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Mode: record-only
Projects: 7
Vue files: 1027
Semantic spans: 45614
False positives: 114
False negatives: 1084
Documented divergences: 0
Digest: 403096248dbda71c75e853d5d90b3dfdbcc9937d925db73f6472cad080f3c60a
