## vue-uploader lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 0be2f9571644ac2f7d3348420baf8fb8105c5555
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 8
Baseline messages dropped as foreign-rule directives: 0

Patina findings: 37
Baseline findings: 849
Comparable baseline findings: 21
Shared: 20
Message differences: 20
Documented divergences: 0
Rule location divergences: 0
False positives: 0 (0.0)
False negatives: 1 (0.047619047619047616)
Unimplemented upstream findings: 828
Intentional divergences: 0
Patina-only rule findings: 17
Baseline parse errors: 0
Baseline invalid ranges: 0
Budget verdict: breached
Budget passed: false

### False positives: none

### False negatives: 1

| Rule | Findings |
| --- | ---: |
| `vue/no-mutating-props` | 1 |

### Rule location divergences: none

### Unimplemented upstream rules: 828

| Rule | Findings |
| --- | ---: |
| `vue/script-indent` | 512 |
| `vue/padding-lines-in-component-definition` | 58 |
| `vue/new-line-between-multi-line-property` | 50 |
| `vue/sort-keys` | 36 |
| `vue/comment-directive` | 32 |
| `vue/component-api-style` | 26 |
| `vue/max-attributes-per-line` | 24 |
| `vue/padding-line-between-tags` | 16 |
| `vue/no-undef-properties` | 10 |
| `vue/order-in-components` | 10 |
| `vue/max-len` | 9 |
| `vue/enforce-style-attribute` | 8 |
| `vue/require-expose` | 8 |
| `vue/require-prop-comment` | 8 |
| `vue/restricted-component-names` | 8 |
| `vue/singleline-html-element-content-newline` | 6 |
| `vue/next-tick-style` | 3 |
| `vue/html-indent` | 1 |
| `vue/no-undef-components` | 1 |
| `vue/prefer-single-event-payload` | 1 |
| `vue/require-name-property` | 1 |

