## gui-for-singbox lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 1be4816dea1e8793d8e08ae4f8f016c28101672d
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 98
Baseline messages dropped as foreign-rule directives: 0

Patina findings: 83
Baseline findings: 5540
Comparable baseline findings: 5
Shared: 2
Message differences: 2
Documented divergences: 0
Rule location divergences: 0
False positives: 3 (0.6)
False negatives: 3 (0.6)
Unimplemented upstream findings: 5535
Intentional divergences: 0
Patina-only rule findings: 78
Baseline parse errors: 1
Baseline invalid ranges: 0
Budget verdict: unusable
Budget passed: false

### False positives: 3

| Rule | Findings |
| --- | ---: |
| `script/no-duplicate-attr-inheritance` | 2 |
| `vue/v-slot-style` | 1 |

### False negatives: 3

| Rule | Findings |
| --- | ---: |
| `vue/no-duplicate-attr-inheritance` | 3 |

### Rule location divergences: none

### Unimplemented upstream rules: 5535

| Rule | Findings |
| --- | ---: |
| `vue/max-attributes-per-line` | 735 |
| `vue/restricted-component-names` | 716 |
| `vue/no-undef-components` | 643 |
| `vue/padding-line-between-tags` | 576 |
| `vue/max-len` | 474 |
| `vue/sort-keys` | 358 |
| `vue/comment-directive` | 323 |
| `vue/static-class-names-order` | 268 |
| `vue/require-prop-comment` | 188 |
| `vue/script-indent` | 187 |
| `vue/object-curly-spacing` | 180 |
| `vue/multiline-ternary` | 168 |
| `vue/singleline-html-element-content-newline` | 163 |
| `vue/block-lang` | 127 |
| `vue/quote-props` | 76 |
| `vue/no-undef-directives` | 73 |
| `vue/array-element-newline` | 37 |
| `vue/object-property-newline` | 34 |
| `vue/no-setup-props-reactivity-loss` | 31 |
| `vue/require-emit-validator` | 28 |
| `vue/no-literals-in-template` | 24 |
| `vue/prefer-template` | 24 |
| `vue/comma-dangle` | 23 |
| `vue/v-if-else-key` | 15 |
| `vue/no-v-model-argument` | 14 |
| `vue/no-extra-parens` | 8 |
| `vue/require-macro-variable-name` | 7 |
| `vue/prefer-single-event-payload` | 5 |
| `vue/html-comment-content-newline` | 4 |
| `vue/no-ref-object-reactivity-loss` | 3 |
| `vue/padding-line-between-blocks` | 3 |
| `vue/prefer-separate-static-class` | 3 |
| `vue/camelcase` | 2 |
| `vue/enforce-style-attribute` | 2 |
| `vue/eqeqeq` | 2 |
| `vue/html-comment-indent` | 2 |
| `vue/no-undef-properties` | 2 |
| `vue/no-v-for-template-key` | 2 |
| `vue/no-constant-condition` | 1 |
| `vue/no-implicit-coercion` | 1 |
| `vue/no-negated-condition` | 1 |
| `vue/padding-lines-in-component-definition` | 1 |
| `vue/space-infix-ops` | 1 |

