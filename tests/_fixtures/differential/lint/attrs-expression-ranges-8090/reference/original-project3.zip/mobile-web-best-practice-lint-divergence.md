## mobile-web-best-practice lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 34a793b13492405f75c97b46253df5ee142014cc
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 7
Baseline messages dropped as foreign-rule directives: 0

Patina findings: 30
Baseline findings: 292
Comparable baseline findings: 15
Shared: 15
Message differences: 15
Documented divergences: 0
Rule location divergences: 0
False positives: 3 (0.16666666666666666)
False negatives: 0 (0.0)
Unimplemented upstream findings: 277
Intentional divergences: 0
Patina-only rule findings: 12
Baseline parse errors: 0
Baseline invalid ranges: 0
Budget verdict: breached
Budget passed: false

### False positives: 3

| Rule | Findings |
| --- | ---: |
| `vue/require-toggle-inside-transition` | 2 |
| `vue/no-mutating-props` | 1 |

### False negatives: none

### Rule location divergences: none

### Unimplemented upstream rules: 277

| Rule | Findings |
| --- | ---: |
| `vue/first-attribute-linebreak` | 40 |
| `vue/html-closing-bracket-newline` | 40 |
| `vue/no-undef-components` | 31 |
| `vue/restricted-component-names` | 31 |
| `vue/comment-directive` | 28 |
| `vue/padding-line-between-tags` | 27 |
| `vue/sort-keys` | 19 |
| `vue/block-lang` | 14 |
| `vue/object-curly-spacing` | 10 |
| `vue/multiline-ternary` | 8 |
| `vue/require-direct-export` | 7 |
| `vue/quote-props` | 6 |
| `vue/multiline-html-element-content-newline` | 4 |
| `vue/no-undef-directives` | 3 |
| `vue/prefer-single-event-payload` | 2 |
| `vue/singleline-html-element-content-newline` | 2 |
| `vue/static-class-names-order` | 2 |
| `vue/enforce-style-attribute` | 1 |
| `vue/max-len` | 1 |
| `vue/object-property-newline` | 1 |

