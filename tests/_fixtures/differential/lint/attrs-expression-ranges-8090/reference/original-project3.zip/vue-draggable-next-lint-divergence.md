## vue-draggable-next lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 8687d34f3182a1a0bfb138e995609f32ffe3ce6b
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 30
Baseline messages dropped as foreign-rule directives: 0

Patina findings: 76
Baseline findings: 1032
Comparable baseline findings: 44
Shared: 44
Message differences: 44
Documented divergences: 0
Rule location divergences: 0
False positives: 0 (0.0)
False negatives: 0 (0.0)
Unimplemented upstream findings: 988
Intentional divergences: 0
Patina-only rule findings: 32
Baseline parse errors: 0
Baseline invalid ranges: 0
Budget verdict: passed
Budget passed: true

### False positives: none

### False negatives: none

### Rule location divergences: none

### Unimplemented upstream rules: 988

| Rule | Findings |
| --- | ---: |
| `vue/comment-directive` | 112 |
| `vue/max-attributes-per-line` | 106 |
| `vue/padding-lines-in-component-definition` | 96 |
| `vue/sort-keys` | 93 |
| `vue/new-line-between-multi-line-property` | 89 |
| `vue/object-curly-spacing` | 65 |
| `vue/restricted-component-names` | 64 |
| `vue/singleline-html-element-content-newline` | 52 |
| `vue/component-api-style` | 51 |
| `vue/padding-line-between-tags` | 39 |
| `vue/require-expose` | 30 |
| `vue/no-undef-components` | 29 |
| `vue/padding-line-between-blocks` | 28 |
| `vue/html-indent` | 20 |
| `vue/quote-props` | 20 |
| `vue/max-len` | 19 |
| `vue/no-literals-in-template` | 16 |
| `vue/static-class-names-order` | 10 |
| `vue/order-in-components` | 9 |
| `vue/object-property-newline` | 7 |
| `vue/require-name-property` | 7 |
| `vue/multiline-ternary` | 6 |
| `vue/require-prop-comment` | 6 |
| `vue/html-closing-bracket-newline` | 4 |
| `vue/no-undef-properties` | 4 |
| `vue/enforce-style-attribute` | 3 |
| `vue/match-component-import-name` | 2 |
| `vue/no-negated-condition` | 1 |

