## bootstrap-vue lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 9a246f45fc813f161df291fc7d6197febf8afaf4
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 22
Baseline messages dropped as foreign-rule directives: 1

Patina findings: 40
Baseline findings: 2187
Comparable baseline findings: 38
Shared: 38
Message differences: 38
Documented divergences: 0
Rule location divergences: 0
False positives: 0 (0.0)
False negatives: 0 (0.0)
Unimplemented upstream findings: 2149
Intentional divergences: 0
Patina-only rule findings: 2
Baseline parse errors: 0
Baseline invalid ranges: 4
Budget verdict: unusable
Budget passed: false

### False positives: none

### False negatives: none

### Rule location divergences: none

### Unimplemented upstream rules: 2149

| Rule | Findings |
| --- | ---: |
| `vue/max-attributes-per-line` | 383 |
| `vue/restricted-component-names` | 249 |
| `vue/max-len` | 227 |
| `vue/no-undef-components` | 219 |
| `vue/padding-line-between-tags` | 195 |
| `vue/padding-lines-in-component-definition` | 128 |
| `vue/singleline-html-element-content-newline` | 126 |
| `vue/new-line-between-multi-line-property` | 118 |
| `vue/sort-keys` | 86 |
| `vue/static-class-names-order` | 85 |
| `vue/comment-directive` | 69 |
| `vue/object-curly-spacing` | 64 |
| `vue/component-api-style` | 46 |
| `vue/multiline-ternary` | 32 |
| `vue/no-undef-properties` | 20 |
| `vue/require-expose` | 17 |
| `vue/array-element-newline` | 15 |
| `vue/v-if-else-key` | 12 |
| `vue/require-prop-comment` | 10 |
| `vue/no-literals-in-template` | 8 |
| `vue/prefer-separate-static-class` | 8 |
| `vue/next-tick-style` | 7 |
| `vue/require-name-property` | 6 |
| `vue/block-lang` | 5 |
| `vue/quote-props` | 5 |
| `vue/no-undef-directives` | 3 |
| `vue/object-property-newline` | 2 |
| `vue/order-in-components` | 2 |
| `vue/html-indent` | 1 |
| `vue/multiline-html-element-content-newline` | 1 |

