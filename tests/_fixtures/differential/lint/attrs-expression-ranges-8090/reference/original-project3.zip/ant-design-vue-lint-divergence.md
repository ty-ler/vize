## ant-design-vue lint divergence

Commit: ef34d1a0409fc711a6c5cefcf0708b0cce78f502
Revision: 7483836f0adac76516e527df893c3d84a7cd4005
Preset: ecosystem
Baseline: eslint-plugin-vue 10.9.2
Compared rules: 200 of 123 mapped
Files: 731
Baseline messages dropped as foreign-rule directives: 6

Patina findings: 387
Baseline findings: 26472
Comparable baseline findings: 129
Shared: 127
Message differences: 127
Documented divergences: 0
Rule location divergences: 0
False positives: 1 (0.0078125)
False negatives: 2 (0.015503875968992248)
Unimplemented upstream findings: 26343
Intentional divergences: 0
Patina-only rule findings: 259
Baseline parse errors: 0
Baseline invalid ranges: 0
Budget verdict: breached
Budget passed: false

### False positives: 1

| Rule | Findings |
| --- | ---: |
| `script/no-duplicate-attr-inheritance` | 1 |

### False negatives: 2

| Rule | Findings |
| --- | ---: |
| `vue/no-duplicate-attr-inheritance` | 2 |

### Rule location divergences: none

### Unimplemented upstream rules: 26343

| Rule | Findings |
| --- | ---: |
| `vue/restricted-component-names` | 4718 |
| `vue/no-undef-components` | 3711 |
| `vue/padding-line-between-tags` | 3052 |
| `vue/comment-directive` | 2807 |
| `vue/singleline-html-element-content-newline` | 2266 |
| `vue/max-attributes-per-line` | 2023 |
| `vue/sort-keys` | 1455 |
| `vue/max-len` | 794 |
| `vue/object-curly-spacing` | 778 |
| `vue/quote-props` | 776 |
| `vue/padding-line-between-blocks` | 670 |
| `vue/no-v-model-argument` | 619 |
| `vue/block-lang` | 595 |
| `vue/block-tag-newline` | 482 |
| `vue/no-literals-in-template` | 272 |
| `vue/comma-dangle` | 179 |
| `vue/object-property-newline` | 175 |
| `vue/padding-lines-in-component-definition` | 161 |
| `vue/multiline-ternary` | 152 |
| `vue/require-expose` | 103 |
| `vue/require-name-property` | 90 |
| `vue/script-indent` | 81 |
| `vue/new-line-between-multi-line-property` | 77 |
| `vue/match-component-import-name` | 66 |
| `vue/array-element-newline` | 51 |
| `vue/require-prop-comment` | 36 |
| `vue/component-api-style` | 23 |
| `vue/enforce-style-attribute` | 23 |
| `vue/html-comment-indent` | 20 |
| `vue/no-v-for-template-key` | 11 |
| `vue/no-extra-parens` | 10 |
| `vue/no-setup-props-reactivity-loss` | 8 |
| `vue/no-ref-object-reactivity-loss` | 7 |
| `vue/no-undef-properties` | 7 |
| `vue/static-class-names-order` | 7 |
| `vue/html-comment-content-newline` | 6 |
| `vue/v-if-else-key` | 6 |
| `vue/dot-location` | 4 |
| `vue/no-implicit-coercion` | 4 |
| `vue/no-undef-directives` | 4 |
| `vue/no-negated-condition` | 3 |
| `vue/require-emit-validator` | 3 |
| `vue/no-console` | 2 |
| `vue/no-constant-condition` | 2 |
| `vue/eqeqeq` | 1 |
| `vue/next-tick-style` | 1 |
| `vue/prefer-separate-static-class` | 1 |
| `vue/prefer-single-event-payload` | 1 |

